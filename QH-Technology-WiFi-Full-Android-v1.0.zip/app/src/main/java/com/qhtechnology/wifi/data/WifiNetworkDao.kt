package com.qhtechnology.wifi.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WifiNetworkDao {
    @Query("SELECT * FROM wifi_networks ORDER BY discoveredAt DESC")
    fun observeAll(): Flow<List<WifiNetwork>>

    @Query("""
        SELECT * FROM wifi_networks
        WHERE ssid LIKE '%' || :q || '%'
           OR bssid LIKE '%' || :q || '%'
        ORDER BY discoveredAt DESC
    """)
    fun search(q: String): Flow<List<WifiNetwork>>

    @Query("SELECT * FROM wifi_networks WHERE bssid = :bssid LIMIT 1")
    suspend fun find(bssid: String): WifiNetwork?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(network: WifiNetwork): Long

    @Update
    suspend fun update(network: WifiNetwork)

    @Query("DELETE FROM wifi_networks")
    suspend fun deleteAll()
}
