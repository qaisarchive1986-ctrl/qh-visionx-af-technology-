package com.qhtechnology.wifi.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "wifi_networks",
    indices = [Index(value = ["bssid"], unique = true)]
)
data class WifiNetwork(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ssid: String,
    val bssid: String,
    val signalDbm: Int,
    val frequencyMhz: Int,
    val latitude: Double?,
    val longitude: Double?,
    val altitude: Double?,
    val accuracyMeters: Float?,
    val discoveredAt: Long
)
